<?php
 
 include(__DIR__ . '\Database\db.php');

 function sanitize_input($data) {
    $data = filter_var($data, FILTER_SANITIZE_STRING);
    return str_replace(['&#34;', '&#39;'], ['"', "'"], $data);
}

function is_slug_unique($con, $slug) {
    $sql = "SELECT COUNT(*) AS slug_count FROM blog_data_v2 WHERE slug = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("s", $slug);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();
    
    return $row['slug_count'] == 0;
}

function validate_inputs($title, $sub, $cat, $status, $content, $slug) {
    if (empty(trim($title)) || empty(trim($sub)) || empty(trim($cat)) || empty(trim($status)) || empty(trim($content)) || empty(trim($slug))) {
        return ["error" => "All fields are required."];
    }

    if (!(strlen($title) > 0 && strlen($title) < 25)) {
        return ["error" => "Title must be between 1 and 25 characters."];
    }

    if (!(strlen($sub) > 0 && strlen($sub) < 75)) {
        return ["error" => "Sub title must be between 1 and 50 characters."];
    }

    return null;
}


function handle_image_upload($image) {
    if ($image) {
        $target_dir = "blog_images/";
        $imageFileType = strtolower(pathinfo($image["name"], PATHINFO_EXTENSION));
        $image_size = $image["size"];

        if ($image_size > 2097152) {
            return ["error" => "File is too large. Maximum allowed size is 2MB."];
        }

        $allowed_types = ["jpg", "jpeg", "png", "gif"];
        if (!in_array($imageFileType, $allowed_types)) {
            return ["error" => "Only JPG, JPEG, PNG & GIF files are allowed."];
        }
            $timestamp = date("YmdHis"); 
            $new_file_name = $target_dir . $timestamp . '.' . $imageFileType;
    
                if (!move_uploaded_file($image["tmp_name"], $new_file_name)) {
                    return ["error" => "There was an error uploading your file."];
            }
         
            $new_file_name = '../'.$target_dir . $timestamp . '.' . $imageFileType;


        return ["path" => $new_file_name];
    }

    return ["path" => null];
}


?>