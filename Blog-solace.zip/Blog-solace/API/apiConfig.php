<?php
$api_key = '24cb57bc20efc903';
?>