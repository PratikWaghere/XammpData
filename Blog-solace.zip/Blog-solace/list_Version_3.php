<?php

header("Content-Type: application/json");

include(__DIR__ . '\Database\db.php');
// include('..\API\apiConfig.php');
// if (isset($api_key) && !empty($api_key)) {
//     $api = "SELECT * FROM api_keys WHERE apiKey = ?";
//     $stmt = $con->prepare($api);
//     $stmt->bind_param("s", $api_key);
//     $stmt->execute();
//     $result = $stmt->get_result();
//     $row = $result->num_rows;

//     if ($row == null) {
//         echo json_encode(array("error" => "Invalid API Key"));
//         exit;
//     } 
//     else{
    
//     }  
// } else {
    //     echo json_encode(array("error" => "API Key not set"));
//     exit;
// }


function getPaginationData($con) {
    if(isset($_GET['slug']) && !empty($_GET['slug'])){
        $slugName = $_GET['slug'];
    }
    
    if (isset($slugName)) {
        $sql = "SELECT id, title, subTitle, blogImg, updateDate, content, catName, blogStatus, slug FROM blog_data_v2 WHERE slug = ?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("s", $slugName);
        $count = 0;
    } else {
        $sql = "SELECT id, title, subTitle, blogImg, updateDate, content, catName, blogStatus, slug  FROM blog_data_v2 WHERE blogStatus = 1";
        $stmt = $con->prepare($sql);
        $count = 1;
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result === false) {                
        return ["error" => $con->error];
    }

    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    
    return $data;
}

$data = getPaginationData($con);
echo json_encode($data);

$con->close();
?>