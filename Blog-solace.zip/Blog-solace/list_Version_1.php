<?php
header("Content-Type: application/json");

require 'Database/db.php';
 
if(isset($_GET['api']) && !empty($_GET['api'])){
    $api_key = $_GET['api'];
    $api = "SELECT * FROM api_keys WHERE api_key = ?";
    $stmt = $con->prepare($api);
    $stmt->bind_param("s", $api_key);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->num_rows;
    if ($row == null) {
        echo json_encode(array("error" => "Invalid API Key"));
        exit;
    } 
    else{
        $data =getDataBlog($con);
        echo json_encode($data);

    }
   }
    else{
        echo json_encode(array("error" => "Invalid API Key"));
    }  

     
function getDataBlog($con){
    if(isset($_GET['id']) && !empty($_GET['id'])){
        $id = $_GET['id'];
        $sql = "SELECT id, title, subtitle, img, uploaddate , content FROM data where id = $id";
    $result = $con->query($sql);
    }else{
        $sql = "SELECT id, title, subtitle, img, uploaddate , content FROM data";
       $result = $con->query($sql);
    }
                                                                                                                      
    if ($result === false) {
        echo json_encode(["error" => $con->error]);
        exit();
    }
    
    $data = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }
    return $data;
    // echo json_encode($data);
}


?>

    