<?php
header('Content-Type: application/json');

include(__DIR__ . '\Database\db.php');
if ($con ->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Connection failed: ".$con ->connect_error]);
    exit;
}

$title = $_POST['title'] ?? null;
$sub = $_POST['sub-title'] ?? null;
$content = $_POST['blog-data'] ?? null;
$image = $_FILES['image'] ?? null;

$title = filter_var($title, FILTER_SANITIZE_STRING);
$sub = filter_var($sub, FILTER_SANITIZE_STRING);
$content = filter_var($content, FILTER_SANITIZE_STRING);

$title = str_replace('&#34;', '"', $title);
$title = str_replace('&#39;', "\'", $title);

$sub = str_replace('&#34;', '"', $sub);
$sub = str_replace('&#39;', "\'", $sub);

$content = str_replace('&#34;', '"', $content);
$content = str_replace('&#39;', "\'", $content);

if (!$title || !$sub || !$content || !$image) {
    http_response_code(400);
    echo json_encode(["error" => "All fields are required."]);
    exit;
}


if(!(strlen($title)> 0 && strlen($title) < 25)){
	http_response_code(400);
	echo json_encode(["error" => "Title must be between 1 and 25 characters."]);
	exit;
}
if(!(strlen($sub)>0 && strlen($sub) < 75)){
	http_response_code(400);
	echo json_encode(["error" => "Sub title must be between 1 and 50 characters."]);
	exit;
}

$target_dir = "blog_images/";
$target_file = $target_dir.basename($image["name"]);
$imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
$image_size = $image["size"];

if ($image_size > 2097152) { // 2MB in bytes
    http_response_code(400);
    echo json_encode(
        ["error" => "File is too large. Maximum allowed size is 2MB."]
    );
    exit;
}

$allowed_types = ["jpg", "jpeg", "png", "gif"];
if (!in_array($imageFileType, $allowed_types)) {
    http_response_code(400);
    echo json_encode(["error" => "Only JPG, JPEG, PNG & GIF files are allowed."]);
    exit;
}

if (!move_uploaded_file($image["tmp_name"], $target_file)) {
    http_response_code(500);
    echo json_encode(["error" => "There was an error uploading your file."]);
    exit;
}

$sql = "INSERT INTO `data` (title, subtitle, img, content, uploaddate)
 VALUES('$title','$sub','$target_file','$content',current_timestamp())";

    if ($con ->query($sql) === TRUE) {
        http_response_code(201);
        echo json_encode(["message" => "New record created successfully"]);
    } else {
        http_response_code(500);
        echo json_encode(["error" => "Error: ".$sql." ".$con ->error]);
    
}

$con->close();
?>
