
CREATE TABLE `api_keys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `apiKey` varchar(64) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `blog_data_v2` (
  `id` tinyint(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(45) NOT NULL,
  `subTitle` varchar(45) NOT NULL,
  `blogImg` varchar(45) NOT NULL,
  `catName` varchar(45) NOT NULL,
  `blogStatus` int(11) NOT NULL,
  `updateDate` date NOT NULL DEFAULT current_timestamp(),
  `content` text NOT NULL,
  `slug` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `blog_categories` (
  `id` int(11) NOT NULL,
  `catName` varchar(45) NOT NULL,
  `updatedDate` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`,`catName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `blog_data_v1` (
  `id` tinyint(11) NOT NULL,
  `title` varchar(45) NOT NULL,
  `subTitle` varchar(45) NOT NULL,
  `blogImg` varchar(45) NOT NULL,
  `uploaddate` date NOT NULL DEFAULT current_timestamp(),
  `content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `blog_categories` (`id`, `catName`, `updatedDate`) VALUES
(1, 'Technology', '2024-08-07 15:44:54'),
(2, 'AI & Machine Learning', '2024-08-07 15:46:29'),
(3, 'Software Development', '2024-08-07 15:46:29'),
(4, 'Gadgets', '2024-08-07 15:46:29'),
(5, 'Cybersecurity', '2024-08-07 15:46:29'),
(6, 'Health & Fitness', '2024-08-07 15:46:29'),
(7, 'Nutrition', '2024-08-07 15:46:29'),
(8, 'Workouts', '2024-08-07 15:46:29'),
(9, 'Mental Health', '2024-08-07 15:46:29'),
(10, 'Medical News', '2024-08-07 15:46:29'),
(11, 'Travel', '2024-08-07 15:46:29'),
(12, 'Destinations', '2024-08-07 15:46:29'),
(13, 'Travel Tips', '2024-08-07 15:46:29'),
(14, 'Culture', '2024-08-07 15:46:29'),
(15, 'Adventure', '2024-08-07 15:46:29'),
(16, 'Food & Cooking', '2024-08-07 15:46:29'),
(17, 'Recipes', '2024-08-07 15:46:29'),
(18, 'Restaurant Reviews', '2024-08-07 15:46:29'),
(19, 'Cooking Tips', '2024-08-07 15:46:29'),
(20, 'Food Trends', '2024-08-07 15:46:29'),
(21, 'Lifestyle', '2024-08-07 15:46:29'),
(22, 'Fashion', '2024-08-07 15:46:29'),
(23, 'Beauty', '2024-08-07 15:46:29'),
(24, 'Home Decor', '2024-08-07 15:46:29'),
(25, 'Personal Development', '2024-08-07 15:46:29'),
(26, 'Finance', '2024-08-07 15:46:29'),
(27, 'Investing', '2024-08-07 15:46:29'),
(28, 'Saving Tips', '2024-08-07 15:46:29'),
(29, 'Personal Finance', '2024-08-07 15:46:29'),
(30, 'Crypto', '2024-08-07 15:46:29'),
(31, 'Education', '2024-08-07 15:46:29'),
(32, 'Online Courses', '2024-08-07 15:46:29'),
(33, 'Study Tips', '2024-08-07 15:46:29'),
(34, 'Career Advice', '2024-08-07 15:46:29'),
(35, 'Academic Research', '2024-08-07 15:46:29'),
(36, 'Entertainment', '2024-08-07 15:46:29'),
(37, 'Movies', '2024-08-07 15:46:29'),
(38, 'TV Shows', '2024-08-07 15:46:29'),
(39, 'Music', '2024-08-07 15:46:29'),
(40, 'Celebrity News', '2024-08-07 15:46:29'),
(41, 'Sports', '2024-08-07 15:46:29'),
(42, 'Football', '2024-08-07 15:46:29'),
(43, 'Basketball', '2024-08-07 15:46:29'),
(44, 'Fitness', '2024-08-07 15:46:29'),
(45, 'Sports News', '2024-08-07 15:46:29'),
(46, 'Business', '2024-08-07 15:46:30'),
(47, 'Startups', '2024-08-07 15:46:30'),
(48, 'Marketing', '2024-08-07 15:46:30'),
(49, 'Management', '2024-08-07 15:46:30'),
(50, 'Entrepreneurship', '2024-08-07 15:46:30'),
(51, 'Other', '2024-08-07 15:47:42');





