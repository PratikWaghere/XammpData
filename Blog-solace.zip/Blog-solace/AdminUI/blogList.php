<?php
session_start();
include('..\Database\db.php');

// Fetch categories
$sql = "SELECT id, catName FROM blog_categories"; 
$result = $con->query($sql);
$categories = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $categories[] = $row;
    }
}

$con->close();

function display_categories($categories, $selectedCategoryId = null) {
    foreach ($categories as $category) {
        $selected = ($category['id'] == $selectedCategoryId) ? 'selected' : '';
        echo "<option id='option-" . $category['id'] . "' " . $selected . ">" . htmlspecialchars($category['catName']) . "</option>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/tinymce@5.10.1/tinymce.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    tinymce.init({
        selector: 'textarea#update-blog-data',
        setup: function(editor) {
            editor.on('change', function() {
                editor.save();
            });
        }
    });

    function fillUpdateForm(data) {
        document.getElementById('update-id').value = data.id;
        document.getElementById('update-title').value = data.title;
        document.getElementById('update-sub-title').value = data.subTitle;
        document.getElementById('current-image').src = data.blogImg;
        document.getElementById('update-blog-data').value = data.content;
        document.getElementById('update-slug').value = data.slug;

        $('#update-categories').find('option:selected').removeAttr('selected');
         
        console.log(data.catName);
        var new_selection = $('#update-categories').find('#option-'+data.catName);
           new_selection.attr("selected",true); 
         console.log(new_selection);


        tinymce.get('update-blog-data').setContent(data.content);
        let statusRadio = document.querySelector(`input[name="status"][value="${data.blogStatus}"]`);
        if (statusRadio) {
            statusRadio.checked = true;
        }

        $("#tbl").fadeOut('fast', function() {
            $("#update-section").fadeIn(300);
        });
    }

    function checkSlug() {
        let inp = document.getElementById("update-title").value;
        if (inp === '') {
            alert("Please fill in the title");
            return false;
        } else {
            let slug = inp.replace(/[^a-zA-Z0-9]+/g, '-').toLowerCase().trim();
            document.getElementById("update-slug").value = slug;
            return true;
        }
    }

    function previewImg() {
        var fileInput = document.getElementById('update-image');
        var previewImg = document.getElementById('current-image');
        if (fileInput.files && fileInput.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                previewImg.src = e.target.result;
                previewImg.style.display = "block";
            }
            reader.readAsDataURL(fileInput.files[0]);
        } else {
            previewImg.src = "";
            previewImg.style.display = "none";
        }
    }

    function removeImg() {
        var fileInput = document.getElementById('update-image');
        var previewImg = document.getElementById('current-image');
        fileInput.value = "";
        previewImg.src = "";
        previewImg.style.display = "none";
    }
    </script>

    <style>
    .card {
        width: 70%;
        margin: 0 auto;
        padding: 30px;
        margin-bottom: 20px;
    }

    img {
        width: 30%;
        justify-content: center;
    }

    h1 {
        text-align: center;
    }

    .table {
        width: 80%;
        margin: 0 auto;
        padding: auto;
    }

    #update-section {
        display: none;
        margin-top: 20px;
    }
    </style>
</head>

<body>

    <h1>Admin Panel</h1>

    <?php if (isset($_SESSION['success'])): ?>
    <div class="alert alert-success">
        <?php echo $_SESSION['success']; ?>
    </div>
    <?php unset($_SESSION['success']); ?>
    <?php elseif (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger">
        <?php echo $_SESSION['error']; ?>
    </div>
    <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <?php
include('..\Database\db.php');

// Fetch blog data
$sql = "SELECT * FROM blog_data_v2";
$result = $con->query($sql);

if ($result->num_rows > 0) {
    echo "<table id='tbl' class='table table-striped'>";
    echo "<thead>";
    echo "<tr>";
    echo "<th>No</th>";
    echo "<th>Image</th>";
    echo "<th>Title</th>";
    echo "<th>Sub Title</th>";
    echo "<th>Update Date</th>";
    echo "<th>Delete</th>";
    echo "<th>Update</th>";
    echo "</tr>";
    echo "</thead>";
    echo "<tbody>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td><img src='" . $row['blogImg'] . "' alt='Image' style='height: 100px; width: 100px;'></td>";
        echo "<td>" . $row['title'] . "</td>";
        echo "<td>" . $row['subTitle'] . "</td>";
        echo "<td>" . $row['updateDate'] . "</td>";
        echo "<td>";
        echo "<form action='deleteBlog.php' method='post'> ";
        echo "<input type='hidden' name='id' value='" . $row['id'] . "'>";
        echo "<input type='submit' value='Delete' class='btn btn-danger'>";
        echo "</form>";
        echo "</td>";
        echo "<td>";
        echo "<button type='button' class='btn btn-warning update' onclick='fillUpdateForm(".json_encode($row).")'>Update</button>";
        echo "</td>";
        echo "</tr>";
    }

    echo "</tbody>";
    echo "</table>";
} else {
    echo "<p style='text-align: center; font-size: 100px;'>Data not found</p>";
}

$con->close();
?>

    <div id="update-section" class="card">
        <script>
        $(document).ready(function() {
            $('#back').click(function() {
                $("#update-section").fadeOut('fast', function() {
                    $("#tbl").fadeIn(300);
                });
            });
        });
        </script>
        <button id='back' class='btn btn-primary ' style='margin-left:800px;'>Cancel</button>

        <h2>Update Blog</h2>
        <form id="updateForm" action="updateForm.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="update-id" name="id">
            <label for="title" class="label-control">Title:</label>
            <input type="text" id="update-title" class="form-control" name="title" required>
            <label for="sub-title" class="label-control">Sub Title:</label>
            <input type="text" id="update-sub-title" class="form-control" name="sub-title" required>
            <label for="image" class="label-control">Image:</label>
            <input type="file" id="update-image" class="form-control" name="image" accept="image/*"
                onchange="previewImg()">
            <img src="" alt="Current Image" id="current-image" height="100px" width="100px">
            <br>
            <label for="categories" class="label-control">Choose a category:</label>
            <select class="form-control" id="update-categories" name="categories" required>
                <option selected>Choose a category</option>
                <?php display_categories($categories); ?>
            </select>
            <br>
            <label for="status" class="label-control">Blog Status:</label>
            <input type="radio" name="status" value="1"> Publish
            <input type="radio" name="status" value="-1"> Draft
            <br>
            <label for="content" class="label-control">Content:</label>
            <textarea id="update-blog-data" name="blog-data" cols="30" rows="10"></textarea>
            <br>
            <input type="hidden" name="slug" id="update-slug">
            <input type="submit" class="btn btn-primary" value="Update" onclick="return checkSlug()">
            <button type="button" class="btn btn-danger" onclick="removeImg()">Remove Image</button>
        </form>
    </div>

</body>

</html>
