<?php
session_start(); // Start session at the beginning

include('..\Database\db.php');
include('..\Create_Version_2.1.php');

function process_blog_data($con) {
    $id = isset($_POST['id']) ? sanitize_input($_POST['id']) : null;
    $title = isset($_POST['title']) ? sanitize_input($_POST['title']) : null;
    $sub = isset($_POST['sub-title']) ? sanitize_input($_POST['sub-title']) : null;
    $cat = $_POST['categories'] ?? null;
    $status = isset($_POST['status']) ? sanitize_input($_POST['status']) : null;
    $content = $_POST['blog-data'] ?? null;
    $image = $_FILES['image'] ?? null;
    $slug = isset($_POST['slug']) ? sanitize_input($_POST['slug']) : null;

    $slug = trim($slug, '-');

    $validation_error = validate_inputs($title, $sub, $cat, $status, $content, $slug);
    if ($validation_error) {
        $_SESSION['error'] = $validation_error;
        header("Location: blogList.php");
        exit;
    }

    function handle_image_upload_update($image) {
        if ($image && $image["size"] > 0) {
            $target_dir = "../blog_images/";
            $imageFileType = strtolower(pathinfo($image["name"], PATHINFO_EXTENSION));
            $image_size = $image["size"];
    
            if ($image_size > 2097152) {
                return ["error" => "File is too large. Maximum allowed size is 2MB."];
            }
    
            $allowed_types = ["jpg", "jpeg", "png", "gif"];
            if (!in_array($imageFileType, $allowed_types)) {
                return ["error" => "Only JPG, JPEG, PNG & GIF files are allowed."];
            }
            $timestamp = date("YmdHis"); 
            $new_file_name = $target_dir . $timestamp . '.' . $imageFileType;
        
            if (!move_uploaded_file($image["tmp_name"], $new_file_name)) {
                return ["error" => "There was an error uploading your file."];
            }

            return ["path" => $new_file_name];
        }
    
        return ["path" => null];
    }

    $image_result = handle_image_upload_update($image);
    if (isset($image_result["error"])) {
        $_SESSION['error'] = $image_result["error"];
        header("Location: blogList.php");
        exit;
    }
    $target_file = $image_result["path"] ?? null;

  if($target_file != null){
      $sql = 'UPDATE `blogdata`.`blog_data_v2` SET `title` = ?, `subTitle` = ?, `blogImg` = ?, `catName` = ?, `blogStatus` = ?, `updateDate` = NOW(), `content` = ?, `slug` = ? WHERE `id` = ?;';
      $stmt = $con->prepare($sql);
      $stmt->bind_param("sssssssi", $title, $sub, $target_file, $cat, $status, $content, $slug, $id);
  }
  else{
    $sql = 'UPDATE `blogdata`.`blog_data_v2` SET `title` = ? , `subTitle` = ?, `catName` = ? , `blogStatus` = ?, `updateDate` = NOW(), `content` = ?, `slug` = ? WHERE `id` = ?;';
    $stmt = $con->prepare($sql);
    $stmt->bind_param("ssssssi", $title, $sub, $cat, $status, $content, $slug, $id);

  }
    if ($stmt === false) {
        $_SESSION['error'] = "SQL Prepare Error: " . $con->error;
        header("Location: blogList.php");
        exit;
    }


    if ($stmt->execute()) {
        $_SESSION['success'] = "Blog updated successfully.";
    } else {
        $_SESSION['error'] = "Error: " . $stmt->error;
    }

    $stmt->close();
    $con->close();

    header("Location: blogList.php");
    exit;
}

process_blog_data($con);
