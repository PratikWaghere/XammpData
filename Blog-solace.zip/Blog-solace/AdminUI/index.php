<?php
require "db.php"; 

if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
} 

$sql = "SELECT id, catName FROM categories"; 
$result = $con->query($sql);

$categories = array();

if ($result-> num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $categories[] = $row;
    }
}

$con->close();

function display_categories($categories) {
    foreach ($categories as $category) {
        echo "<option value='" . $category['id'] . "'>" . htmlspecialchars($category['catName']) . "</option>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdn.jsdelivr.net/npm/tinymce@5.10.1/tinymce.min.js" referrerpolicy="origin"></script>
    <script>
        tinymce.init({
            selector: 'textarea#blog-data',
            setup: function (editor) {
                editor.on('change', function () {
                    editor.save();
                });
            }
        });
    </script>

    <style>
        .form-data {
            width: 100%;
            margin: 0 auto;
            font-weight: bold;
        }

        form {
            width: 50%;
            margin: 0 auto;
            padding: auto;
        }

        h2 {
            text-align: center;
        }

        #pre {
            display: none;
        }
    </style>
    <title>Admin-Blog-solace</title>
</head>

<body>
    <div class="form-data">
        <h2>Fill data for Blog</h2>

        <form action="dummycreate.php" method="post" enctype="multipart/form-data">
            <label for="title" class="label-control">Title:</label>
            <input type="text" id="title" class="form-control" name="title" required>
            <label for="sub-title" class="label-control">Sub Title:</label>
            <input type="text" id="sub-title" class="form-control" name="sub-title" required>
            <label for="image" class="label-control">Image:</label>
            <input type="file" id="image" class="form-control" name="image" accept="image/*">

            <div class="preview" id="preview">
                <br>
                <button type="button" class="btn btn-primary" onclick="previewImg()">Preview</button>
                <button type="button" class="btn btn-primary" onclick="removeImg()">Remove Image</button>
                <img src="" alt="Image Preview" id="pre" height="100px" width="100px">
            </div>
            <br>

            <label for="categories" class="label-control">Choose a category:</label>
            <select id="categories" name="categories">
                <?php display_categories($categories); ?>
            </select>
            <br>
            <label for="status" class="label-control">Blog Status:  </label>
            <input type="radio" name="status" value="Publish"> Publish 
            <input type="radio" name="status" value="Draft"> Draft 
            <br>
            <label for="content" class="label-control">Content:</label>

            <textarea class="form-control" name="blog-data" id="blog-data" cols="30" rows="20">Write here</textarea>
            <br>

            <input type="text" name="slug" id="slug" style="display:none;">

            <input type="submit" id="upload" onclick="checkSlug()"  class="btn btn-primary" value="Upload data">
        </form>
    </div>

    <script>
        function previewImg() {
            var fileInput = document.getElementById('image');
            var previewImg = document.getElementById('pre');
 
            if (fileInput.files && fileInput.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    previewImg.src = e.target.result;
                    previewImg.style.display = "block";
                }
                reader.readAsDataURL(fileInput.files[0]);
            } else {
                previewImg.src = "";
                previewImg.style.display = "none";
            }
            let j = document.getElementById("blog-data").value;
            console.log(j);
            console.log('hello');
        }
       
        function removeImg(){
            var fileInput = document.getElementById('image');
            var previewImg = document.getElementById('pre');
            fileInput.value = "";
            previewImg.src = "";
            previewImg.style.display = "none";

        }

        function checkSlug(){
            let inp = document.getElementById("title").value;
             
            if(inp == ''){
                alert("please fill the data");
                return false;
            }
             else{
                let slug = inp.replace(/[^a-zA-Z0-9]+/g, '-').toLowerCase().trim();
                document.getElementById("slug").value = slug;
                return true;


             }            

        }
         
     
    </script>
</body>

</html>
