<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main page</title>
    <style>
        .card{
            margin: 0 auto;
            width: 70%;
            padding: 30px;
            margin-bottom: 20px;
            background-color: whitesmoke;
            border-radius: 20px;
        }
        img{
           width: 100%;
        }
        .card-body{
            display: flex;
            justify-content: space-around;
        }
    </style>
</head>
<body>
    <?php
         include('..\Database\db.php');
         $slug = $_GET['slug'];
         $sql = "SELECT id, title, subTitle, blogImg, updateDate , content FROM blog_data_v2 where slug = $slug"; 

         $result = $con->query($sql);

         if (!empty($result) && $result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<div class='card'>
                  <img src='" . ($row['blogImg']) . "' alt='Image'>
                 <h2 class='card-header'>"."Title : ". $row['title'] . "</h1>
                   <div class='card-body'>
                     <h3 class='card-title'>"."Sub Title : " . $row['subTitle'] . "</h3>
                     <h4 class='card-title'>"."Last updated date : " . $row['updateDate'] . "</h4>
                   </div>
                   <p>".$row['content']."</p>
              </div>";
            }   
         }
         else{
            echo "No data found";
         }    
    ?> 
    

</body>
</html>