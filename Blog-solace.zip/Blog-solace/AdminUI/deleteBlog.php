<?php
      include('..\Database\db.php');
      function deleteBlog($con,$id){
        $sql = 'DELETE FROM `blogdata`.`blog_data_v2` WHERE id = ?'; 
        $stmt = $con->prepare($sql);
        $stmt->bind_param("i", $id);
        if($stmt->execute()){
            header("Location: blogList.php");
            return true;
        }
        else{
            header("Location: blogList.php");
            return false;
        }
      }
 
      
      if(isset($_POST['id']) && !empty($_POST['id'])){
           $id = $_POST['id'];
           deleteBlog($con,$id);
      }
      else{
        header("Location: blogList.php");
      }
          

?>

