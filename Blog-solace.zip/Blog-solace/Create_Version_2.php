<?php
session_start(); // Start session at the beginning

include('.\Database\db.php');
require "Create_Version_2.1.php";

function process_blog_data($con) {
    $title = isset($_POST['title']) ? sanitize_input($_POST['title']) : null;
    $sub = isset($_POST['sub-title']) ? sanitize_input($_POST['sub-title']) : null;
    $cat = isset($_POST['categories']) ? sanitize_input($_POST['categories']) : null;
    $status = isset($_POST['status']) ? sanitize_input($_POST['status']) : null;
    $content = isset($_POST['blog-data']) ? sanitize_input($_POST['blog-data']) : null;
    $image = $_FILES['image'] ?? null;
    $slug = isset($_POST['slug']) ? sanitize_input($_POST['slug']) : null;

    $slug = trim($slug, '-');

    $validation_error = validate_inputs($title, $sub, $cat, $status, $content, $slug);
    if ($validation_error) {
        $_SESSION['error'] = $validation_error;
        header("Location: AdminUI/blogForm.php");
        exit;
    }

    if (!is_slug_unique($con, $slug)) {
        $_SESSION['error'] = "Slug already exists.";
        header("Location: AdminUI/blogForm.php");
        exit;
    }

    $image_result = handle_image_upload($image);
    if (isset($image_result["error"])) {
        $_SESSION['error'] = $image_result["error"];
        header("Location: AdminUI/blogForm.php");
        exit;
    }
    $target_file = $image_result["path"];

    $sql = "INSERT INTO `blogdata`.`blog_data_v2` (`title`, `subTitle`, `blogImg`, `catName`, `blogStatus`, `updateDate`, `content`, `slug`) VALUES (?, ?, ?, ?, ?, current_timestamp(), ?, ?)";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("sssssss", $title, $sub, $target_file, $cat, $status, $content, $slug);

    if ($stmt->execute()) {
        $_SESSION['success'] = "New record created successfully.";
    } else {
        $_SESSION['error'] = "Error: " . $stmt->error;
    }

    $stmt->close();
    $con->close();

    header("Location: AdminUI/blogForm.php");
    exit;
}

process_blog_data($con);
