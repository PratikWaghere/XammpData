<?php

header("Content-Type: application/json");

include(__DIR__ . '\Database\db.php');
include(__DIR__ .'\API\apiConfig.php');

function getPaginationData($con, $page, $limit, $cnt) {
    $offset = ($page - 1) * $limit;

    if (isset($_GET['slug']) && !empty($_GET['slug'])) {
        $slugName = $_GET['slug'];

        $sql = "SELECT id, title, subTitle, blogImg, updateDate, content, catName, blogStatus, slug FROM blog_data_v2 WHERE slug = ?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("s", $slugName);
        $count = 0;
    } else {
        if ($limit == 0) {
            $sql = "SELECT id, title, subtitle, blogImg, updateDate, content, catName, blogStatus, slug FROM blog_data_v2 WHERE blogStatus = 1 ";
            $stmt = $con->prepare($sql);
        } else {
            $sql = "SELECT id, title, subtitle, blogImg, updateDate, content, catName, blogStatus, slug FROM blog_data_v2 WHERE blogStatus = 1 LIMIT ?, ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param("ii", $offset, $limit);
        }
        $count = 1;
    }
    
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result === false) {                
        return ["error" => $con->error];
    }

    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    $page_cnt = [];
    if ($count == 1 && isset($cnt) && !empty($cnt)) {
        $page_cnt['total_page'] = $limit != 0 ? ceil($cnt / $limit) : 1;
        $page_cnt['total_col'] = $cnt;
    }

    return [$data, $page_cnt];
}


if ($api_key) {
    $api = "SELECT * FROM api_keys WHERE apiKey = ?";
    $stmt = $con->prepare($api);
    $stmt->bind_param("s", $api_key);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 0) {
        echo json_encode(["error" => "Invalid API Key"]);
        exit;
    }
} else {
    echo json_encode(["error" => "API Key not set"]);
    exit;
}


$total = "SELECT COUNT(*) as total FROM blog_data_v2 WHERE blogStatus = 1 ";
$result = $con->query($total);
$cnt = $result->fetch_assoc()['total'];


$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 6;


$data = getPaginationData($con, $page, $limit, $cnt);

echo json_encode($data);

$con->close();

?>
